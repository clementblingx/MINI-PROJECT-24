let icon = document.querySelector(".icon");
let ul = document.querySelector("ul");


icon.addEventListener("click", ()=>{
    ul.classList.toggle("showData");
     
    if(ul.className == "showData"){
        document.getElementById("bar").className= "fa-solid fa-xmark";
    } else{
        document.getElementById("bar").className= "fa-solid fa-bars";

    }
    
})



// card js

let shopCrd = document.querySelectorAll(".shopCrd");
let itemPage = document.querySelector(".itemPage")
let container = document.querySelector(".container");
let itemImg = document.getElementById("itemImg");
let buyBtn = document.getElementById("buyBtn");

console.log(shopCrd);


    shopCrd.forEach(function(curValue){
         curValue.addEventListener("click", function(){
            itemPage.style.display="flex";
            container.style.display="none";

            let imgSrc = curValue.firstElementChild.src ;
            itemImg.src=imgSrc;
             
            let buyText =  document.querySelector(".buyText");
            buyBtn.addEventListener("click", function(){
                document.querySelector(".buyPage").style.display="block";
                buyText.innerHTML=`
                <h3>Enter Details :</h3>
                <input type="text" placeholder="Enter Your Name" id="name" required> <br>
                <input type="text" placeholder="Enter Your Address" id="address" required> <br>
                <input type="text" placeholder="Enter Your Mobile Number" id="num" required> <br>
                <h3>Payment Plan :</h3>
                <select>
                    <option value="MoMo">MoMo</option>
                    <option value="Cash">Cash</option>
                    <option value="VisaCard">VisaCard</option>
    
                </select> <br>
                
    
                `
               let button =  document.createElement("button");
               button.innerText="Submit";
               buyText.appendChild(button);

               button.addEventListener("click", function(){
               let name = document.getElementById("name");

               if(name.value == "" && address.value == "" && num.value == ""){
                alert("Please Type In Your Details")
               }else{
                alert("Your Response Recorded");
                document.querySelector(".buyPage").style.display="none";

               }
               })
                 
                let cancel = document.querySelector(".cancel");
                cancel.addEventListener("click", function(){
                document.querySelector(".buyPage").style.display="none";

                }
                )
            })

             
         })

    })
 
 
    // connect

    function connect(){
        let names = document.getElementById("names");
        let num = document.getElementById("number");
        if(names.value == "" && num.value == ""){
            alert("Fill Details")
        }else{
            alert("Thanks For Connecting")
        }

    }