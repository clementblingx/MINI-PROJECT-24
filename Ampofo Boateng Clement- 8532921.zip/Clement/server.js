const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');

const app = express();
const port = 3000;

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'bysel'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to database');
});

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Serve static files (including your HTML file)
app.use(express.static(path.join(__dirname, 'public')));

// Handle login
app.post('/login', (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    const query = 'SELECT * FROM login WHERE user = ? AND password = ?';
    db.query(query, [email, password], (err, results) => {
        if (err) throw err;
        if (results.length > 0) {
            res.json({ success: true });
        } else {
            res.json({ success: false });
        }
    });
});

// Handle signup
app.post('/signup', (req, res) => {
    const { fname, lastname, email, number, password, gender } = req.body;

    const query = 'INSERT INTO login (firstName, lastName, user, number, password, gender) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(query, [fname, lastname, email, number, password, gender], (err, results) => {
        if (err) {
            console.error('Error during database query:', err);
            res.status(500).json({ success: false });
            return;
        }
        res.json({ success: true });
    });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
